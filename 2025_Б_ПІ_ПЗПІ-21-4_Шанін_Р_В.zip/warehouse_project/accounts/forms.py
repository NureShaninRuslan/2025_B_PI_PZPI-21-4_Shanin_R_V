from django import forms
from django.contrib.auth.models import User
from .models import Role

class RegistrationForm(forms.Form):
    username = forms.CharField(
        label="Логін (Username)", 
        max_length=100,
        widget=forms.TextInput(attrs={'class': 'form-control'})
    )
    full_name = forms.CharField(
        label="Повне ім'я", 
        max_length=255,
        widget=forms.TextInput(attrs={'class': 'form-control'})
    )
    password = forms.CharField(
        label="Пароль", 
        widget=forms.PasswordInput(attrs={'class': 'form-control'})
    )
    password_confirm = forms.CharField(
        label="Підтвердіть пароль", 
        widget=forms.PasswordInput(attrs={'class': 'form-control'})
    )
    # ModelChoiceField автоматично завантажить всі доступні ролі з БД
    role = forms.ModelChoiceField(
        queryset=Role.objects.all(),
        label="Роль",
        empty_label="Оберіть роль",
        widget=forms.Select(attrs={'class': 'form-control'})
    )

    def clean_username(self):
        """ Перевірка, чи не зайнятий логін. """
        username = self.cleaned_data.get('username')
        if User.objects.filter(username=username).exists():
            raise forms.ValidationError("Цей логін вже зайнятий.")
        return username

    def clean(self):
        """ Перевірка, чи співпадають паролі. """
        cleaned_data = super().clean()
        password = cleaned_data.get("password")
        password_confirm = cleaned_data.get("password_confirm")

        if password and password_confirm and password != password_confirm:
            raise forms.ValidationError("Паролі не співпадають.")
        return cleaned_data