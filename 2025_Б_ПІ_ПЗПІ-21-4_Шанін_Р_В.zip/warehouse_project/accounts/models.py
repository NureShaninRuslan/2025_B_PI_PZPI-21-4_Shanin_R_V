from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver

# Модель для таблиці 'roles'
class Role(models.Model):
    name = models.CharField(max_length=50, unique=True, verbose_name="Назва ролі")

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "Роль"
        verbose_name_plural = "Ролі"
        # Вказуємо, що Django має створити таблицю 'roles'
        db_table = 'roles'


# Розширюємо стандартну модель User, додаючи до неї роль та повне ім'я
# Це реалізація таблиці 'users' з вашого SQL
class UserProfile(models.Model):
    # OneToOneField гарантує, що один користувач має лише один профіль
    user = models.OneToOneField(User, on_delete=models.CASCADE, primary_key=True, related_name='profile')
    full_name = models.CharField(max_length=255, verbose_name="Повне ім'я")
    role = models.ForeignKey(Role, on_delete=models.SET_NULL, null=True, blank=True, verbose_name="Роль")
    
    # created_at та password_hash вже є у стандартній моделі User
    
    def __str__(self):
        return self.user.username

    class Meta:
        verbose_name = "Профіль користувача"
        verbose_name_plural = "Профілі користувачів"
        # Вказуємо, що Django має створити таблицю 'users_profile'
        # (не 'users', бо та вже зайнята вбудованою моделлю)
        db_table = 'user_profiles'


# Сигнал, який автоматично створює UserProfile, коли створюється новий User
@receiver(post_save, sender=User)
def create_user_profile(sender, instance, created, **kwargs):
    if created:
        UserProfile.objects.create(user=instance)

@receiver(post_save, sender=User)
def save_user_profile(sender, instance, **kwargs):
    instance.profile.save()
