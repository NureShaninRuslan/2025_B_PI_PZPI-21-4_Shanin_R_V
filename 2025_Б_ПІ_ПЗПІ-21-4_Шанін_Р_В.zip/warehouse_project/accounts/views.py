from django.shortcuts import render, redirect
from django.contrib.auth import login
from django.contrib.auth.models import User
from .forms import RegistrationForm

def register_view(request):
    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        if form.is_valid():
            # Отримуємо валідні дані
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            full_name = form.cleaned_data['full_name']
            role = form.cleaned_data['role']

            # Створюємо користувача. create_user автоматично хешує пароль.
            user = User.objects.create_user(username=username, password=password)
            
            # Оновлюємо профіль додатковими даними
            user.profile.full_name = full_name
            user.profile.role = role
            user.save() # Зберігає і User, і пов'язаний UserProfile

            # Автоматично логінимо користувача після реєстрації
            login(request, user)
            
            # Перенаправляємо на головну сторінку (або іншу)
            return redirect('/') # Потрібно буде створити URL для '/'
    else:
        form = RegistrationForm()
        
    return render(request, 'accounts/register.html', {'form': form})